sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("samplecds9feappone.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);