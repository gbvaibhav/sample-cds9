sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("com.shell.sample.cds9.samplecds9uiappone.controller.App", {
        onInit() {
        }
    });
});