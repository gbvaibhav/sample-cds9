sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("com.shell.sample.cds9.samplecds9uiappone.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map